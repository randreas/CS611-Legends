/*
 * Enum of hero classes available
 */
public enum HeroClass {
	WARRIOR,
	SORCERER,
	PALADIN;
}
