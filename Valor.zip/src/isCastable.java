/*
 * isCastable.java - interface which are castable
 */
public interface isCastable {
	public abstract void cast(Hero caster, Character opponent);
}
