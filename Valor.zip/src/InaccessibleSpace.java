
/*
 * InaccessibleSpace.java - java class that creates an inaccessible space
 */
public class InaccessibleSpace extends ValorSpace{

	public InaccessibleSpace( int row, int col) {
		super("#", row, col);
		// TODO Auto-generated constructor stub
	}

}
