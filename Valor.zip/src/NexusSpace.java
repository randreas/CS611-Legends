
public class NexusSpace extends ValorSpace {

	public NexusSpace( int row, int col) {
		super("N", row, col);
	}

}
