/*
 * isConsumable.java - interface for objects that are consumable
 */
public interface isConsumable {
	public abstract void consume(Character c);
}
