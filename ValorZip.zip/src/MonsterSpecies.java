/*
 * MonsterSpecies.java - enum for list of monster species
 */
public enum MonsterSpecies {
	DRAGON,
	EXOSKELETON,
	SPIRIT;
}
