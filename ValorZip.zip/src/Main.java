/*
 * Main.java - main class
 */
public class Main {
	/*
	 * Main function to create a LegendsGame instance and play the game.
	 */
	public static void main(String[] args) {
		ValorGame valor = new ValorGame();
		valor.startGame();
	}
}
