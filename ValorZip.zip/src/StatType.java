/*
 * StatType.java - enum for list of stats for characters
 */
public enum StatType {
	HEALTH,
	MANA,
	STRENGTH,
	DEXTERITY,
	AGILITY,
	DEFENSE;
	
}
