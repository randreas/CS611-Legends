/*
 * SpellType.java -  enum of spell types
 */
public enum SpellType {
	ICE,
	FIRE,
	LIGHTNING;
}
