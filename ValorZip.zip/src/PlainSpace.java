/*
 * PlainSpace.java - a blocked space instance which does nothing special. 
 */
public class PlainSpace extends ValorSpace {

	public PlainSpace( int row, int col) {
		super("P", row, col);
	}

}
