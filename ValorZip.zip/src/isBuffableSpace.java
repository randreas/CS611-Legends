
public interface isBuffableSpace {
	public abstract void enterSpaceBuff(Hero h);
	public abstract void exitSpaceDeBuff(Hero h);
}
